# LocalCloud redesign — change summary

Status: NOT built or type-checked (sandbox had no network, so `yarn install` was impossible).
Only a syntax-level TypeScript parse check was run. Run these before deploying:

    yarn install && yarn tsc && yarn lint && yarn build:production

## New files (resources/scripts)
- assets/localcloud.css                      shell/layout/card/badge/progress styles (tokens live in GlobalStylesheet)
- components/localcloud/LocalCloudLayout.tsx sidebar + header + content shell (drawer under 1024px)
- components/localcloud/LocalCloudSidebar.tsx, LocalCloudNav.tsx, LocalCloudHeader.tsx, LocalCloudLogo.tsx
- components/localcloud/LocalCloudCard.tsx, LocalCloudBadge.tsx, LocalCloudProgress.tsx

## Modified
- tailwind.config.js                 inverted gray scale -> light theme, soft-blue primary, 14-20px radii, hard ink shadows
- assets/css/GlobalStylesheet.ts     CSS variables (design tokens), focus-visible ring, reduced-motion
- routers/DashboardRouter.tsx, routers/ServerRouter.tsx   use LocalCloudLayout; server links moved to sidebar (same routes + permission gating)
- components/dashboard/DashboardContainer.tsx   hero, stat cards, server grid (real API data)
- components/dashboard/ServerRow.tsx            card with live CPU/memory/disk meters (same polling as before)
- elements/button/style.module.css, Input.tsx, Modal.tsx, ContentBox.tsx, GreyRowBox.tsx, SubNavigation.tsx, PageContentBlock.tsx
- server/console/style.module.css, Console.tsx  navy terminal, ink border, hard shadow (WebSocket code untouched)
- auth/LoginFormContainer.tsx        LocalCloud logo/tagline
- resources/views/templates/wrapper.blade.php, config/app.php   default app name / theme colors

## Untouched on purpose
API layer, state, WebSocket handlers, auth/session, window.PterodactylUser contract, PHP backend, DB.

## Phase 2 — dark theme, backgrounds, i18n, pins (this update)
- Tailwind palette is now a calm dark slate-navy scale (non-inverted); thin borders + soft shadows replace the offset-ink look.
- Custom background: dashboard (per user, saved in the browser) and login page (per browser, plus optional admin default via
  LOCALCLOUD_LOGIN_BG in .env). Presets, solid colour, uploaded image (auto-downscaled) or https URL, dim + blur sliders.
- ID/EN language switch for the LocalCloud shell (sidebar, header, dashboard, appearance dialog).
- Dashboard: pin servers, filter by name/status, sort by name/status (applies to the current page of results).
- LocalCloud favicons + PWA manifest (installable on phones over HTTPS).
- New: components/localcloud/{appearance.ts,i18n.ts,LocalCloudBackground.tsx,AppearanceModal.tsx}

## Phase 2b — command palette, server header, System Health, public status page
Frontend
- Ctrl/Cmd+K command palette (pages, actions, live server search; Start/Restart/Stop/Kill when inside a server).
- Server page: back link, name + live status badge, Start/Restart/Stop + always-visible Kill (confirm dialog), CPU/Memory/Disk meters.
Backend (new, run `php artisan migrate --force` once)
- /admin/health (+ /admin/health/json): MariaDB, PHP-FPM, Nginx, queue worker, scheduler heartbeat, load/RAM/disk. Super admins only.
- /status and /status.json (public): per-service state, 30-day uptime bars, recent incidents, ID/EN.
  Data comes from the `localcloud:record-status` command, scheduled every minute (the scheduler loop started by `localcloud start`).
- New table: localcloud_status_checks (95-day retention). Optional .env: LOCALCLOUD_STATUS_NODES=false hides node names.

## Phase 3 — portal: register, templates, plans, QRIS (run `localcloud update` once after applying)
New tables: localcloud_plans (5 sample plans), _templates, _registrations, _trial_claims, _orders, _subscriptions.
- Runtime templates (not games): Node.js, Python, Bun, Java, Linux(Debian) — database/localcloud/eggs/*.json,
  imported into a "Runtimes" nest by `php artisan localcloud:install-templates`. Each starts a small hello-world app on the assigned port;
  optional Git repository clone/auto-pull.
- Public site: / (landing, guests only), /register (email verification + Turnstile + disposable-mail block), /legal/*, /status.
- Portal (login + 2FA rules like the panel): /portal/deploy wizard, /portal/orders, /portal/subscriptions (renew).
- Payments: QRIS via the gateway in LOCALCLOUD_PG_URL/KEY. No webhook exists, so the browser page and `localcloud:billing`
  (every minute) poll /api/qr-status; amount + unique tx id are checked before provisioning.
- Lifecycle: reminders H-3/H-1, suspend at expiry, delete after LOCALCLOUD_GRACE_DAYS (default 7).
- Anti-abuse: one trial per account/normalised email/IP, max servers per account, node capacity + plan stock checks.
- Installer: `localcloud mail` (Gmail SMTP), `localcloud portal` (gateway/Turnstile/support), `localcloud update`.

## Phase 3b — admin portal, abuse watch, docs
- /admin/localcloud (super admins): edit/create plans (prices, limits, stock, trial), toggle templates, last 50 orders with "retry",
  and servers auto-suspended for abuse with a "restore" button. Run `localcloud update` (adds column suspend_reason).
- `localcloud:abuse-watch` (every 2 min): suspends a running server whose CPU stays >= LOCALCLOUD_ABUSE_CPU_PERCENT (95) of its plan
  limit for LOCALCLOUD_ABUSE_SAMPLES (30) consecutive checks; owner is emailed; renewals do not lift it; admin restores manually.
- Public: /docs (7 guides), /contact (mail to LOCALCLOUD_SUPPORT_EMAIL, Turnstile), /changelog.

## Installer 1.1 — patch / doctor / uninstall
- `localcloud patch <file|url>`: validates the archive (gzip, no absolute or ".." paths), backs up overwritten files to
  /var/backups/localcloud, extracts, runs composer dump-autoload, verifies `localcloud:*` commands (prints diagnostics incl. php -l), clears caches.
- `localcloud doctor`: 13 health checks with suggested fixes.
- `localcloud uninstall`: optional backup (DB dump + .env + storage/app), type HAPUS to confirm, drops DB/user, removes panel/config/logs/autostart,
  optional package purge (+ optional /var/lib/mysql wipe).
- Error handling: known-error hints after a failed step, lock file against concurrent runs, menu actions isolated so a failure never closes the menu.

## Phase 4 — growth features (run `localcloud update`, then `localcloud rebuild`)
- Environment manager (server tab "Environment"): edits /.env through the file API; values hidden by default, bulk import,
  reserved names blocked, never overwrites a file it failed to read. Egg start-up now sources .env (verified with a simulated yolks entrypoint);
  `localcloud:install-templates` syncs existing eggs and servers still on the stock command.
- Invoices (/portal/orders/{id}/invoice): printable page (Save as PDF from the browser), billing profile (/portal/billing), seller details via LOCALCLOUD_COMPANY_*.
- Coupons (percent / fixed / bonus days; limits per user, plan, cycle, first purchase) + referral (/portal/referral): rewards on the referee's first PAID order,
  IP-based self-referral guard. Admin: /admin/localcloud has the coupon manager.
- Plan change (/portal/subscriptions/{id}/change): pro-rata upgrade, free immediate downgrade with disk-usage check, trial -> paid on the same server.
- Git deploy (/portal/servers/{short}/git): per-server webhook (GitHub / GitLab / Gitea, HMAC or secret token), "Deploy now", history.
  A deploy = AUTO_UPDATE=1 + restart (the template start-up runs git pull and reinstalls dependencies).
- Domains (/portal/servers/{short}/domains): <label>.LOCALCLOUD_BASE_DOMAIN subdomains and TXT-verified custom domains.
  PHP writes storage/app/localcloud/domains.map; a root helper (`localcloud __domainsync`, started by `localcloud start`) validates it and reloads nginx.
  `localcloud domains` configures the proxy (port 8081), edge CNAME/IPs and prints Cloudflare Tunnel / Caddy instructions.
- New tables: coupons, coupon_uses, referral_codes, referrals, billing_profiles, git_hooks, deployments, domains (+ order columns).
