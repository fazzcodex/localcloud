<?php

namespace Pterodactyl\Console\Commands\LocalCloud;

use Illuminate\Console\Command;
use Pterodactyl\Services\LocalCloud\Portal\DomainService;

class SyncDomainsCommand extends Command
{
    protected $signature = 'localcloud:sync-domains';

    protected $description = 'Regenerate the reverse-proxy domain map (host => node:port).';

    public function handle(DomainService $domains): int
    {
        $this->info($domains->syncMap() ? 'Domain map updated.' : 'Domain map already up to date.');

        return Command::SUCCESS;
    }
}
