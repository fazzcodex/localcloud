<?php

namespace Pterodactyl\Console\Commands\LocalCloud;

use Illuminate\Console\Command;
use Pterodactyl\Services\LocalCloud\Portal\BillingService;

class BillingCommand extends Command
{
    protected $signature = 'localcloud:billing';

    protected $description = 'Confirm QRIS payments, provision paid orders, send reminders, suspend expired servers and purge abandoned ones.';

    public function handle(BillingService $billing): int
    {
        $billing->runLifecycle();

        return Command::SUCCESS;
    }
}
