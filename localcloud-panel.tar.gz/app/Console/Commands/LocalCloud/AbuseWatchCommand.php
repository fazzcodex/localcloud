<?php

namespace Pterodactyl\Console\Commands\LocalCloud;

use Illuminate\Console\Command;
use Pterodactyl\Services\LocalCloud\Portal\AbuseWatchService;

class AbuseWatchCommand extends Command
{
    protected $signature = 'localcloud:abuse-watch';

    protected $description = 'Suspend servers that keep their CPU pinned at the plan limit.';

    public function handle(AbuseWatchService $watch): int
    {
        $watch->run();

        return Command::SUCCESS;
    }
}
