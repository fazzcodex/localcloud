<?php

namespace Pterodactyl\Console\Commands\LocalCloud;

use Illuminate\Support\Str;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\Nest;
use Illuminate\Console\Command;
use Illuminate\Http\UploadedFile;
use Pterodactyl\Models\LocalCloud\Template;
use Pterodactyl\Services\Eggs\Sharing\EggImporterService;

class InstallTemplatesCommand extends Command
{
    protected $signature = 'localcloud:install-templates';

    protected $description = 'Import the LocalCloud runtime eggs (Node.js, Python, Bun, Java, Linux) and register them as deployable templates.';

    /** slug => [egg name, label, description, sort] */
    private const TEMPLATES = [
        'nodejs' => ['Node.js', 'JS', 'Web app, API, bot atau worker Node.js. Bisa langsung dari repositori Git.', 1],
        'python' => ['Python', 'PY', 'Skrip, Flask/FastAPI, bot dan worker Python dengan pip otomatis.', 2],
        'bun' => ['Bun', 'BUN', 'Runtime JavaScript/TypeScript super cepat untuk aplikasi modern.', 3],
        'java' => ['Java', 'JV', 'Jalankan aplikasi Java apa pun dalam bentuk file .jar.', 4],
        'linux' => ['Linux (Debian)', 'SH', 'Container Debian bersih untuk Go, Rust, PHP, atau binary buatan sendiri.', 5],
    ];

    public function handle(EggImporterService $importer): int
    {
        $nest = Nest::query()->where('name', 'Runtimes')->first();
        if (!$nest) {
            $nest = (new Nest())->forceFill([
                'uuid' => Str::uuid()->toString(),
                'author' => 'support@localcloud.local',
                'name' => 'Runtimes',
                'description' => 'Runtime templates for LocalCloud (Node.js, Python, Bun, Java, Linux).',
            ]);
            $nest->save();
            $this->info('Created nest "Runtimes".');
        }

        foreach (self::TEMPLATES as $slug => [$eggName, $label, $description, $sort]) {
            $path = database_path('localcloud/eggs/' . $slug . '.json');
            if (!is_file($path)) {
                $this->warn("Missing egg file for {$slug}, skipped.");
                continue;
            }

            $egg = Egg::query()->where('nest_id', $nest->id)->where('name', $eggName)->first();
            if (!$egg) {
                $file = new UploadedFile($path, basename($path), 'application/json', null, true);
                $egg = $importer->handle($file, $nest->id);
                $this->info("Imported egg: {$eggName}");
            } else {
                // Keep existing eggs (and servers still on the egg's stock command) in sync with the shipped start-up script.
                $new = (string) (json_decode((string) file_get_contents($path), true)['startup'] ?? '');
                if ($new !== '' && $egg->startup !== $new) {
                    $moved = Server::query()->where('egg_id', $egg->id)->where('startup', $egg->startup)->update(['startup' => $new]);
                    Egg::query()->where('id', $egg->id)->update(['startup' => $new]);
                    $this->info("Updated start-up of {$eggName} ({$moved} server(s) followed).");
                }
            }

            Template::query()->updateOrCreate(['slug' => $slug], [
                'name' => $eggName,
                'description' => $description,
                'icon' => $label,
                'egg_id' => $egg->id,
                'sort' => $sort,
                'active' => true,
            ]);
        }

        $this->info('Templates ready.');

        return Command::SUCCESS;
    }
}
