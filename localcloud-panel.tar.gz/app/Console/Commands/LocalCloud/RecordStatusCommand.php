<?php

namespace Pterodactyl\Console\Commands\LocalCloud;

use Illuminate\Console\Command;
use Pterodactyl\Services\LocalCloud\StatusService;

class RecordStatusCommand extends Command
{
    protected $signature = 'localcloud:record-status';

    protected $description = 'Record a health sample for the LocalCloud public status page.';

    public function handle(StatusService $status): int
    {
        $status->record();

        return Command::SUCCESS;
    }
}
