<?php

namespace Pterodactyl\Console\Commands\LocalCloud;

use Symfony\Component\Yaml\Yaml;
use Pterodactyl\Models\Node;
use Pterodactyl\Models\Location;
use Illuminate\Console\Command;
use Pterodactyl\Services\Nodes\NodeCreationService;
use Pterodactyl\Services\Allocations\AssignmentService;
use Pterodactyl\Services\Locations\LocationCreationService;
use Pterodactyl\Repositories\Wings\DaemonConfigurationRepository;

/**
 * Creates (or updates) the local Wings node, its port allocations, and writes the Wings config.yml.
 * Safe to run repeatedly: the node is looked up by name and capacity/ports are refreshed in place.
 */
class RegisterNodeCommand extends Command
{
    protected $signature = 'localcloud:register-node
                            {--name=Local Node : Node name}
                            {--fqdn= : Address the panel and browsers use to reach Wings (IP or hostname)}
                            {--scheme=http : http or https (https when a proxy/tunnel terminates TLS)}
                            {--proxy=0 : 1 when Wings sits behind a proxy/tunnel}
                            {--memory= : Usable memory in MB}
                            {--disk= : Usable disk in MB}
                            {--over-memory=0 : Memory over-allocation in percent}
                            {--over-disk=0 : Disk over-allocation in percent}
                            {--daemon-port=8080 : Port the panel and browsers connect to (443 behind a tunnel)}
                            {--local-port= : Port Wings itself listens on (defaults to --daemon-port)}
                            {--sftp-port=2022 : Wings SFTP port}
                            {--ports=25000-25199 : Allocation ports, comma separated, ranges allowed}
                            {--alias= : Address shown next to allocations}
                            {--remote= : URL Wings uses to reach this panel (default: APP_URL)}
                            {--origin=* : Extra allowed browser origin (repeatable)}
                            {--location=local : Location short code}
                            {--base=/var/lib/pterodactyl/volumes : Wings data directory}
                            {--data-root= : Root folder for Wings data (volumes, backups, archives), e.g. an external SSD}
                            {--write-config= : Write the Wings config.yml to this path}
                            {--check : Only test that the panel can reach Wings}';

    protected $description = 'Register the local Wings node (with allocations) and write its config.yml.';

    public function __construct(
        private NodeCreationService $nodes,
        private LocationCreationService $locations,
        private AssignmentService $allocations
    ) {
        parent::__construct();
    }

    public function handle(): int
    {
        $name = (string) $this->option('name');

        if ($this->option('check')) {
            return $this->check($name);
        }

        $fqdn = trim((string) $this->option('fqdn'));
        $memory = (int) $this->option('memory');
        $disk = (int) $this->option('disk');
        if ($fqdn === '' || $memory < 256 || $disk < 1024) {
            $this->error('--fqdn, --memory (>= 256 MB) and --disk (>= 1024 MB) are required.');

            return Command::FAILURE;
        }
        $scheme = $this->option('scheme') === 'https' ? 'https' : 'http';

        $location = Location::query()->where('short', $this->option('location'))->first()
            ?? $this->locations->handle(['short' => (string) $this->option('location'), 'long' => 'LocalCloud local location']);

        $fields = [
            'fqdn' => $fqdn,
            'scheme' => $scheme,
            'behind_proxy' => (bool) (int) $this->option('proxy'),
            'memory' => $memory,
            'memory_overallocate' => (int) $this->option('over-memory'),
            'disk' => $disk,
            'disk_overallocate' => (int) $this->option('over-disk'),
            'daemonListen' => (int) $this->option('daemon-port'),
            'daemonSFTP' => (int) $this->option('sftp-port'),
        ];

        $node = Node::query()->where('name', $name)->first();
        if ($node) {
            Node::query()->where('id', $node->id)->update($fields);
            $node = Node::query()->find($node->id);
            $this->info("Updated node #{$node->id} ({$name}).");
        } else {
            $node = $this->nodes->handle($fields + [
                'name' => $name,
                'description' => 'Created by the LocalCloud installer',
                'location_id' => $location->id,
                'public' => true,
                'maintenance_mode' => false,
                'upload_size' => 512,
                'daemonBase' => (string) $this->option('base'),
            ]);
            $this->info("Created node #{$node->id} ({$name}).");
        }

        $this->assignPorts($node);
        $this->writeConfig($node);

        return Command::SUCCESS;
    }

    private function assignPorts(Node $node): void
    {
        // The service accepts at most 1000 ports per range, so long ranges are cut into chunks.
        $ports = [];
        foreach (array_filter(array_map('trim', explode(',', (string) $this->option('ports')))) as $part) {
            if (preg_match('/^(\d{4,5})-(\d{4,5})$/', $part, $m)) {
                for ($start = (int) $m[1]; $start <= (int) $m[2]; $start += 1000) {
                    $ports[] = $start . '-' . min($start + 999, (int) $m[2]);
                }
            } elseif (ctype_digit($part)) {
                $ports[] = $part;
            }
        }
        if (!$ports) {
            return;
        }

        $this->allocations->handle($node, [
            'allocation_ip' => '0.0.0.0',
            'allocation_alias' => ((string) $this->option('alias')) ?: null,
            'allocation_ports' => $ports,
        ]);
        $this->info('Allocations ready: ' . implode(', ', $ports));
    }

    private function writeConfig(Node $node): void
    {
        $path = (string) $this->option('write-config');
        if ($path === '') {
            return;
        }

        $config = $node->getConfiguration();
        // Behind a tunnel the panel talks to :443, but Wings itself keeps listening on its local port.
        $config['api']['port'] = (int) ($this->option('local-port') ?: $node->daemonListen);

        if ($remote = trim((string) $this->option('remote'))) {
            $config['remote'] = $remote;
        }
        // When "remote" is a local address the browser origin no longer matches it, so allow the panel URL explicitly.
        $origins = array_values(array_unique(array_filter(array_map('trim', (array) $this->option('origin')))));
        if ($origins) {
            $config['allowed_origins'] = $origins;
        }

        if ($root = rtrim(trim((string) $this->option('data-root')), '/')) {
            $config['system']['root_directory'] = $root;
            $config['system']['data'] = $root . '/volumes';
            $config['system']['archive_directory'] = $root . '/archives';
            $config['system']['backup_directory'] = $root . '/backups';
        }

        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        file_put_contents($path, Yaml::dump($config, 4, 2, Yaml::DUMP_EMPTY_ARRAY_AS_SEQUENCE));
        chmod($path, 0600);
        $this->info("Wrote Wings configuration to {$path}");
    }

    private function check(string $name): int
    {
        $node = Node::query()->where('name', $name)->first();
        if (!$node) {
            $this->error("Node '{$name}' does not exist.");

            return Command::FAILURE;
        }

        try {
            $info = app(DaemonConfigurationRepository::class)->setNode($node)->getSystemInformation();
        } catch (\Throwable $e) {
            $this->error('Panel cannot reach Wings yet: ' . $e->getMessage());

            return Command::FAILURE;
        }

        $this->info('Wings is reachable. Version ' . ($info['version'] ?? 'unknown'));

        return Command::SUCCESS;
    }
}
