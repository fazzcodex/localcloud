<?php

namespace Pterodactyl\Http\Middleware;

use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * LocalCloud: restrict infrastructure areas (nodes, locations, DB hosts, settings, API keys)
 * to the user IDs listed in LOCALCLOUD_SUPER_ADMIN_IDS (comma separated, default "1").
 * Must run after AdminAuthenticate, so the user is already a root admin.
 */
class SuperAdminOnly
{
    public static function allowed(?int $userId): bool
    {
        return $userId !== null && in_array($userId, config('localcloud.super_admin_ids', [1]), true);
    }

    public function handle(Request $request, \Closure $next): mixed
    {
        $user = $request->user();
        if (!$user || !$user->root_admin || !self::allowed((int) $user->id)) {
            throw new AccessDeniedHttpException('This area is restricted to LocalCloud super admins.');
        }

        return $next($request);
    }
}
