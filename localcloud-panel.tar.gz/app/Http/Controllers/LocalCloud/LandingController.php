<?php

namespace Pterodactyl\Http\Controllers\LocalCloud;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\LocalCloud\Plan;
use Pterodactyl\Models\LocalCloud\Template;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Controllers\Base\IndexController;
use Pterodactyl\Services\LocalCloud\Portal\PortalMail;
use Pterodactyl\Services\LocalCloud\Portal\RegistrationService;
use Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication;

class LandingController extends Controller
{
    public function index(Request $request)
    {
        // Signed-in users keep getting the React dashboard at "/", including the 2FA enforcement.
        if (Auth::check()) {
            return app(RequireTwoFactorAuthentication::class)->handle($request, fn () => app(IndexController::class)->index());
        }

        // Only real numbers are shown; a stat is hidden until there is data behind it.
        $stats = ['servers' => Server::query()->whereNull('status')->count(), 'users' => User::query()->count(), 'uptime' => null];
        $since = now()->subDays(30);
        $row = DB::table('localcloud_status_checks')->where('service', 'panel')->where('checked_at', '>=', $since)
            ->selectRaw('COUNT(*) as c, SUM(ok) as s')->first();
        if ($row && (int) $row->c >= 1440) {
            $stats['uptime'] = round($row->s / $row->c * 100, 2);
        }

        return view('localcloud.landing', [
            'plans' => Plan::query()->where('active', true)->orderBy('sort')->get(),
            'templates' => Template::query()->where('active', true)->whereNotNull('egg_id')->orderBy('sort')->get(),
            'stats' => $stats,
        ]);
    }

    public function docs(?string $slug = null)
    {
        $docs = config('localcloud_docs');
        if ($slug === null) {
            return view('localcloud.docs', ['docs' => $docs, 'slug' => null]);
        }
        abort_unless(isset($docs[$slug]), 404);

        return view('localcloud.docs', ['docs' => $docs, 'slug' => $slug]);
    }

    public function contact(RegistrationService $registration)
    {
        return view('localcloud.contact', [
            'siteKey' => $registration->turnstileEnabled() ? config('localcloud.turnstile_site_key') : null,
        ]);
    }

    public function sendContact(Request $request, RegistrationService $registration)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:80'],
            'email' => ['required', 'email:rfc', 'max:191'],
            'subject' => ['required', 'string', 'max:120'],
            'message' => ['required', 'string', 'min:10', 'max:4000'],
        ]);

        if (!$registration->turnstileOk($request->input('cf-turnstile-response'), (string) $request->ip())) {
            return back()->withInput()->withErrors(['captcha' => 'Verifikasi captcha gagal. Coba lagi.']);
        }

        $to = config('localcloud.support_email');
        if (empty($to)) {
            return back()->withInput()->withErrors(['message' => 'Formulir kontak belum diaktifkan. Gunakan tautan dukungan di footer.']);
        }

        $sent = PortalMail::send(
            $to,
            '[Kontak] ' . $data['subject'],
            'Pesan baru dari formulir kontak',
            '<p><strong>' . e($data['name']) . '</strong> &lt;' . e($data['email']) . '&gt; (IP ' . e((string) $request->ip()) . ')</p><p>' . nl2br(e($data['message'])) . '</p>'
        );
        if (!$sent) {
            return back()->withInput()->withErrors(['message' => 'Pesan gagal dikirim. Coba lagi nanti.']);
        }

        return view('localcloud.notice', ['title' => 'Pesan terkirim', 'message' => 'Terima kasih. Kami akan membalas ke ' . e($data['email']) . '.']);
    }

    public function changelog()
    {
        return view('localcloud.changelog');
    }

    public function legal(string $page)
    {
        abort_unless(in_array($page, ['terms', 'privacy', 'refund'], true), 404);

        return view('localcloud.legal', ['page' => $page]);
    }
}
