<?php

namespace Pterodactyl\Http\Controllers\LocalCloud;

use Illuminate\Http\Request;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\LocalCloud\Portal\GitDeployService;
use Pterodactyl\Services\LocalCloud\Portal\PortalException;

class GitController extends Controller
{
    public function __construct(private GitDeployService $git)
    {
    }

    // ------------------------------------------------------------ webhook (public, token + signature)

    public function receive(Request $request, string $token)
    {
        $hook = DB::table('localcloud_git_hooks')->where('token', $token)->first();
        if (!$hook) {
            abort(404);
        }

        $payload = $request->getContent();
        if (!$this->authentic($request, $payload, $hook->secret)) {
            abort(403);
        }

        $event = $request->header('X-GitHub-Event') ?: $request->header('X-Gitlab-Event') ?: $request->header('X-Gitea-Event') ?: $request->header('X-Forgejo-Event');
        if ($event === 'ping') {
            return response()->json(['ok' => true, 'message' => 'pong']);
        }
        if (!$hook->auto_deploy) {
            return response()->json(['ok' => true, 'ignored' => 'auto deploy disabled'], 202);
        }

        $data = json_decode($payload, true) ?: [];
        $ref = (string) ($data['ref'] ?? '');
        if ($ref !== 'refs/heads/' . $hook->branch) {
            return response()->json(['ok' => true, 'ignored' => 'branch'], 202);
        }
        if ($hook->last_deploy_at && now()->diffInSeconds($hook->last_deploy_at) < 20) {
            return response()->json(['ok' => false, 'message' => 'too many deploys'], 429);
        }

        $server = Server::query()->find($hook->server_id);
        if (!$server) {
            abort(404);
        }

        $commits = $data['commits'] ?? [];
        $message = $data['head_commit']['message'] ?? (is_array($commits) && $commits ? (end($commits)['message'] ?? null) : null);

        try {
            $this->git->trigger($server, 'webhook', $ref, $data['after'] ?? ($data['checkout_sha'] ?? null), $message);
        } catch (PortalException $e) {
            return response()->json(['ok' => false, 'message' => $e->getMessage()], 502);
        }

        return response()->json(['ok' => true, 'message' => 'deploy triggered']);
    }

    private function authentic(Request $request, string $payload, string $secret): bool
    {
        $mac = hash_hmac('sha256', $payload, $secret);

        $github = (string) $request->header('X-Hub-Signature-256');
        if ($github !== '' && hash_equals('sha256=' . $mac, $github)) {
            return true;
        }
        foreach (['X-Gitea-Signature', 'X-Forgejo-Signature', 'X-Gogs-Signature'] as $header) {
            $sig = (string) $request->header($header);
            if ($sig !== '' && hash_equals($mac, $sig)) {
                return true;
            }
        }
        $gitlab = (string) $request->header('X-Gitlab-Token');

        return $gitlab !== '' && hash_equals($secret, $gitlab);
    }

    // ------------------------------------------------------------ owner pages

    private function owned(string $short): Server
    {
        return Server::query()->where('uuidShort', $short)->where('owner_id', Auth::id())->firstOrFail();
    }

    public function show(string $short)
    {
        $server = $this->owned($short);
        $hook = $this->git->hook($server);
        $repo = (string) $this->git->variable($server, 'GIT_ADDRESS');

        return view('localcloud.git', [
            'server' => $server,
            'hook' => $hook,
            'url' => url('/hooks/git/' . $hook->token),
            'supported' => $this->git->supported($server),
            // Never echo credentials that may be embedded in the clone URL.
            'repo' => preg_replace('#//[^/@]+@#', '//***@', $repo),
            'cloneBranch' => $this->git->variable($server, 'GIT_BRANCH'),
            'history' => DB::table('localcloud_deployments')->where('server_id', $server->id)->orderByDesc('id')->limit(10)->get(),
        ]);
    }

    public function save(Request $request, string $short)
    {
        $server = $this->owned($short);
        $data = $request->validate(['branch' => ['required', 'string', 'max:100']]);

        try {
            $this->git->save($server, $data['branch'], $request->boolean('auto_deploy'));
        } catch (PortalException $e) {
            return back()->withErrors(['branch' => $e->getMessage()]);
        }

        return back()->with('success', 'Pengaturan deploy disimpan.');
    }

    public function deploy(string $short)
    {
        $server = $this->owned($short);

        try {
            $this->git->trigger($server, 'manual');
        } catch (PortalException $e) {
            return back()->withErrors(['deploy' => $e->getMessage()]);
        }

        return back()->with('success', 'Deploy dimulai: server di-restart dan akan melakukan git pull + install dependensi.');
    }

    public function regenerate(string $short)
    {
        $this->git->regenerate($this->owned($short));

        return back()->with('success', 'URL dan secret webhook diganti. Perbarui di GitHub/GitLab.');
    }
}
