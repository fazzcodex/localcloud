<?php

namespace Pterodactyl\Http\Controllers\LocalCloud;

use Illuminate\Http\Request;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\LocalCloud\Portal\DomainService;
use Pterodactyl\Services\LocalCloud\Portal\PortalException;

class DomainController extends Controller
{
    public function __construct(private DomainService $domains)
    {
    }

    private function owned(string $short): Server
    {
        return Server::query()->with(['allocation', 'node'])->where('uuidShort', $short)->where('owner_id', Auth::id())->firstOrFail();
    }

    public function show(string $short)
    {
        $server = $this->owned($short);
        $rows = $this->domains->list($server);
        $routing = [];
        foreach ($rows as $row) {
            if ($row->kind === 'custom') {
                $routing[$row->host] = $this->domains->routingOk($row->host);
            }
        }

        return view('localcloud.domains', [
            'server' => $server,
            'rows' => $rows,
            'routing' => $routing,
            'enabled' => $this->domains->enabled(),
            'base' => config('localcloud.base_domain'),
            'edgeCname' => config('localcloud.edge_cname'),
            'edgeIps' => config('localcloud.edge_ips'),
            'maxCustom' => (int) config('localcloud.max_custom_domains'),
            'port' => optional($server->allocation)->port,
        ]);
    }

    public function subdomain(Request $request, string $short)
    {
        $server = $this->owned($short);
        $data = $request->validate(['label' => ['required', 'string', 'max:40']]);

        try {
            $this->domains->setSubdomain($server, $data['label']);
        } catch (PortalException $e) {
            return back()->withErrors(['label' => $e->getMessage()])->withInput();
        }

        return back()->with('success', 'Subdomain disimpan. Perubahan aktif dalam ±15 detik.');
    }

    public function custom(Request $request, string $short)
    {
        $server = $this->owned($short);
        $data = $request->validate(['host' => ['required', 'string', 'max:190']]);

        try {
            $this->domains->addCustom($server, $data['host']);
        } catch (PortalException $e) {
            return back()->withErrors(['host' => $e->getMessage()])->withInput();
        }

        return back()->with('success', 'Domain ditambahkan. Buat record DNS di bawah, lalu klik Verifikasi.');
    }

    public function verify(string $short, int $id)
    {
        try {
            $this->domains->verify($this->owned($short), $id);
        } catch (PortalException $e) {
            return back()->withErrors(['verify' => $e->getMessage()]);
        }

        return back()->with('success', 'Domain terverifikasi. Aktif dalam ±15 detik.');
    }

    public function remove(string $short, int $id)
    {
        $this->domains->remove($this->owned($short), $id);

        return back()->with('success', 'Domain dihapus.');
    }

    /** Caddy on-demand TLS "ask" endpoint: 200 only for hostnames we actually serve. */
    public function check(Request $request)
    {
        $expected = (string) config('localcloud.proxy_token');
        if ($expected === '' || !hash_equals($expected, (string) $request->query('token'))) {
            abort(403);
        }

        $domain = strtolower((string) $request->query('domain'));

        return $domain !== '' && $this->domains->isServed($domain) ? response('ok', 200) : response('no', 404);
    }
}
