<?php

namespace Pterodactyl\Http\Controllers\LocalCloud;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\LocalCloud\StatusService;

class StatusController extends Controller
{
    public function __construct(private StatusService $status)
    {
    }

    public function index(Request $request): View
    {
        $lang = $request->query('lang');
        if (!in_array($lang, ['id', 'en'], true)) {
            $lang = str_starts_with(strtolower((string) $request->getPreferredLanguage(['id', 'en'])), 'id') ? 'id' : 'en';
        }

        return view('localcloud.status', ['data' => $this->status->build(), 'lang' => $lang]);
    }

    public function json(): JsonResponse
    {
        return response()->json($this->status->build())->header('Cache-Control', 'public, max-age=30');
    }
}
