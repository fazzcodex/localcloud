<?php

namespace Pterodactyl\Http\Controllers\LocalCloud;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Services\LocalCloud\Portal\ReferralService;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\LocalCloud\Plan;
use Pterodactyl\Models\LocalCloud\Order;
use Pterodactyl\Models\LocalCloud\Template;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\LocalCloud\Subscription;
use Pterodactyl\Services\LocalCloud\Portal\BillingService;
use Pterodactyl\Services\LocalCloud\Portal\PaymentGateway;
use Pterodactyl\Services\LocalCloud\Portal\PortalException;

class PortalController extends Controller
{
    public function __construct(private BillingService $billing, private PaymentGateway $gateway, private ReferralService $referrals)
    {
    }

    public function deploy(Request $request)
    {
        $user = Auth::user();
        $plans = Plan::query()->where('active', true)->orderBy('sort')->get()->map(function (Plan $plan) {
            $plan->remaining = $this->billing->remainingStock($plan);

            return $plan;
        });

        return view('localcloud.deploy', [
            'templates' => Template::query()->where('active', true)->whereNotNull('egg_id')->orderBy('sort')->get(),
            'plans' => $plans,
            'trialOk' => $this->billing->trialEligible($user, (string) $request->ip()),
            'preselect' => $request->query('template'),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'template_id' => ['required', 'integer'],
            'plan_id' => ['required', 'integer'],
            'cycle' => ['nullable', 'in:month,year'],
            'name' => ['required', 'string', 'min:3', 'max:60', 'regex:/^[\w\.\- ]+$/u'],
            'coupon' => ['nullable', 'string', 'max:40'],
        ], ['name.regex' => 'Nama server hanya boleh huruf, angka, spasi, titik, strip, dan underscore.']);

        $plan = Plan::query()->find($data['plan_id']);
        $template = Template::query()->find($data['template_id']);
        if (!$plan || !$template) {
            return back()->withInput()->withErrors(['plan_id' => 'Plan atau template tidak ditemukan.']);
        }

        try {
            $order = $this->billing->createNewOrder(Auth::user(), $plan, $template, $data['name'], $data['cycle'] ?? 'month', (string) $request->ip(), $data['coupon'] ?? null);
        } catch (PortalException $e) {
            return back()->withInput()->withErrors(['plan_id' => $e->getMessage()]);
        }

        if ($order->status === 'active' && $order->server_id) {
            $server = Server::query()->find($order->server_id);
            if ($server) {
                return redirect('/server/' . $server->uuidShort);
            }
        }

        return redirect()->route('localcloud.portal.order', $order->public_id);
    }

    public function orders()
    {
        return view('localcloud.orders', [
            'orders' => Order::query()->with(['plan', 'template'])->where('user_id', Auth::id())->latest()->limit(50)->get(),
        ]);
    }

    public function order(string $id)
    {
        $order = $this->mine($id);
        $order = $this->billing->refresh($order);

        return view('localcloud.order', [
            'order' => $order->load(['plan', 'template']),
            'qrImage' => $order->qris_id ? $this->gateway->imageUrl($order->qris_id) : null,
            'server' => $order->server_id ? Server::query()->find($order->server_id) : null,
        ]);
    }

    public function status(string $id)
    {
        $order = $this->billing->refresh($this->mine($id));
        $server = $order->server_id ? Server::query()->find($order->server_id) : null;

        return response()->json([
            'status' => $order->status,
            'note' => $order->note,
            'seconds_remaining' => $order->qris_expires_at ? (int) max(0, now()->diffInSeconds($order->qris_expires_at, false)) : 0,
            'redirect' => $order->status === 'active' && $server ? '/server/' . $server->uuidShort : null,
        ]);
    }

    public function newQris(string $id)
    {
        $order = $this->mine($id);

        try {
            $this->billing->renewQris($this->billing->refresh($order));
        } catch (PortalException $e) {
            return back()->withErrors(['order' => $e->getMessage()]);
        }

        return redirect()->route('localcloud.portal.order', $order->public_id);
    }

    public function subscriptions()
    {
        $subs = Subscription::query()->with('plan')->where('user_id', Auth::id())->where('status', '!=', 'deleted')->latest()->get();
        $servers = Server::query()->whereIn('id', $subs->pluck('server_id'))->get()->keyBy('id');

        return view('localcloud.subscriptions', ['subs' => $subs, 'servers' => $servers]);
    }

    public function renew(Request $request, int $id)
    {
        $data = $request->validate(['cycle' => ['required', 'in:month,year']]);
        $sub = Subscription::query()->with('plan')->where('user_id', Auth::id())->findOrFail($id);

        try {
            $order = $this->billing->createRenewal(Auth::user(), $sub, $data['cycle'], (string) $request->ip());
        } catch (PortalException $e) {
            return back()->withErrors(['renew' => $e->getMessage()]);
        }

        return redirect()->route('localcloud.portal.order', $order->public_id);
    }

    public function coupon(Request $request): JsonResponse
    {
        $plan = Plan::query()->find((int) $request->query('plan_id'));
        if (!$plan) {
            return response()->json(['ok' => false, 'message' => 'Pilih plan terlebih dulu.']);
        }

        try {
            $q = $this->billing->couponQuote((string) $request->query('code', ''), Auth::user(), $plan, (string) $request->query('cycle', 'month'));
        } catch (PortalException $e) {
            return response()->json(['ok' => false, 'message' => $e->getMessage()]);
        }

        $parts = [];
        if ($q['discount'] > 0) {
            $parts[] = 'Hemat Rp ' . number_format($q['discount'], 0, ',', '.');
        }
        if ($q['bonus_days'] > 0) {
            $parts[] = 'Bonus ' . $q['bonus_days'] . ' hari';
        }

        return response()->json(['ok' => true, 'discount' => $q['discount'], 'final' => $q['final'], 'bonus_days' => $q['bonus_days'], 'message' => 'Kupon diterapkan. ' . implode(' · ', $parts)]);
    }

    public function invoice(string $id)
    {
        $order = $this->mine($id);
        abort_unless($order->paid_at && (int) $order->amount > 0, 404);

        $user = Auth::user();
        $profile = DB::table('localcloud_billing_profiles')->where('user_id', $user->id)->first();
        $tax = (float) config('localcloud.tax_percent');

        return view('localcloud.invoice', [
            'order' => $order->load(['plan', 'template']),
            'user' => $user,
            'profile' => $profile,
            'number' => 'INV-' . $order->created_at->format('Ym') . '-' . str_pad((string) $order->id, 5, '0', STR_PAD_LEFT),
            'taxPercent' => $tax,
            'taxAmount' => $tax > 0 ? (int) round($order->amount * $tax / (100 + $tax)) : 0,
        ]);
    }

    public function billing()
    {
        return view('localcloud.billing', ['profile' => DB::table('localcloud_billing_profiles')->where('user_id', Auth::id())->first()]);
    }

    public function saveBilling(Request $request)
    {
        $data = $request->validate([
            'name' => ['nullable', 'string', 'max:120'],
            'company' => ['nullable', 'string', 'max:120'],
            'tax_id' => ['nullable', 'string', 'max:40'],
            'address' => ['nullable', 'string', 'max:500'],
        ]);

        DB::table('localcloud_billing_profiles')->updateOrInsert(['user_id' => Auth::id()], $data + ['updated_at' => now()]);

        return redirect()->route('localcloud.portal.billing')->with('success', 'Data penagihan disimpan. Berlaku untuk semua invoice.');
    }

    public function referral()
    {
        $stats = $this->referrals->stats(Auth::user());

        return view('localcloud.referral', [
            'stats' => $stats,
            'link' => url('/register?ref=' . $stats['code']),
            'reward' => (int) config('localcloud.referral_reward_days'),
            'bonus' => (int) config('localcloud.referral_bonus_days'),
        ]);
    }

    public function change(int $id)
    {
        $sub = Subscription::query()->with('plan')->where('user_id', Auth::id())->findOrFail($id);
        $server = Server::query()->find($sub->server_id);
        $options = [];
        foreach (Plan::query()->where('active', true)->where('is_trial', false)->orderBy('sort')->get() as $plan) {
            foreach ($sub->is_trial ? ['month', 'year'] : [null] as $cycle) {
                try {
                    $options[] = ['plan' => $plan, 'quote' => $this->billing->quoteChange($sub, $plan, $cycle), 'error' => null];
                } catch (PortalException $e) {
                    if ($plan->id !== $sub->plan_id) {
                        $options[] = ['plan' => $plan, 'quote' => null, 'error' => $e->getMessage(), 'cycle' => $cycle];
                    }
                }
            }
        }

        return view('localcloud.change', ['sub' => $sub, 'server' => $server, 'options' => $options]);
    }

    public function changeStore(Request $request, int $id)
    {
        $data = $request->validate(['plan_id' => ['required', 'integer'], 'cycle' => ['nullable', 'in:month,year']]);
        $sub = Subscription::query()->with('plan')->where('user_id', Auth::id())->findOrFail($id);
        $plan = Plan::query()->find($data['plan_id']);
        if (!$plan) {
            return back()->withErrors(['plan_id' => 'Plan tidak ditemukan.']);
        }

        try {
            $order = $this->billing->createUpgrade(Auth::user(), $sub, $plan, $data['cycle'] ?? null, (string) $request->ip());
        } catch (PortalException $e) {
            return back()->withErrors(['plan_id' => $e->getMessage()]);
        }

        if ($order->status === 'active') {
            return redirect()->route('localcloud.portal.subscriptions')->with('success', 'Plan diubah ke ' . $plan->name . '. Restart server agar batas baru berlaku.');
        }

        return redirect()->route('localcloud.portal.order', $order->public_id);
    }

    private function mine(string $id): Order
    {
        return Order::query()->where('public_id', $id)->where('user_id', Auth::id())->firstOrFail();
    }
}
