<?php

namespace Pterodactyl\Http\Controllers\LocalCloud;

use Illuminate\Http\Request;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\LocalCloud\Plan;
use Pterodactyl\Models\LocalCloud\Order;
use Pterodactyl\Models\LocalCloud\Template;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\LocalCloud\Subscription;
use Pterodactyl\Services\LocalCloud\Portal\BillingService;
use Pterodactyl\Services\LocalCloud\Portal\PaymentGateway;
use Pterodactyl\Services\LocalCloud\Portal\PortalException;

class PortalController extends Controller
{
    public function __construct(private BillingService $billing, private PaymentGateway $gateway)
    {
    }

    public function deploy(Request $request)
    {
        $user = Auth::user();
        $plans = Plan::query()->where('active', true)->orderBy('sort')->get()->map(function (Plan $plan) {
            $plan->remaining = $this->billing->remainingStock($plan);

            return $plan;
        });

        return view('localcloud.deploy', [
            'templates' => Template::query()->where('active', true)->whereNotNull('egg_id')->orderBy('sort')->get(),
            'plans' => $plans,
            'trialOk' => $this->billing->trialEligible($user, (string) $request->ip()),
            'preselect' => $request->query('template'),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'template_id' => ['required', 'integer'],
            'plan_id' => ['required', 'integer'],
            'cycle' => ['nullable', 'in:month,year'],
            'name' => ['required', 'string', 'min:3', 'max:60', 'regex:/^[\w\.\- ]+$/u'],
        ], ['name.regex' => 'Nama server hanya boleh huruf, angka, spasi, titik, strip, dan underscore.']);

        $plan = Plan::query()->find($data['plan_id']);
        $template = Template::query()->find($data['template_id']);
        if (!$plan || !$template) {
            return back()->withInput()->withErrors(['plan_id' => 'Plan atau template tidak ditemukan.']);
        }

        try {
            $order = $this->billing->createNewOrder(Auth::user(), $plan, $template, $data['name'], $data['cycle'] ?? 'month', (string) $request->ip());
        } catch (PortalException $e) {
            return back()->withInput()->withErrors(['plan_id' => $e->getMessage()]);
        }

        if ($order->status === 'active' && $order->server_id) {
            $server = Server::query()->find($order->server_id);
            if ($server) {
                return redirect('/server/' . $server->uuidShort);
            }
        }

        return redirect()->route('localcloud.portal.order', $order->public_id);
    }

    public function orders()
    {
        return view('localcloud.orders', [
            'orders' => Order::query()->with(['plan', 'template'])->where('user_id', Auth::id())->latest()->limit(50)->get(),
        ]);
    }

    public function order(string $id)
    {
        $order = $this->mine($id);
        $order = $this->billing->refresh($order);

        return view('localcloud.order', [
            'order' => $order->load(['plan', 'template']),
            'qrImage' => $order->qris_id ? $this->gateway->imageUrl($order->qris_id) : null,
            'server' => $order->server_id ? Server::query()->find($order->server_id) : null,
        ]);
    }

    public function status(string $id)
    {
        $order = $this->billing->refresh($this->mine($id));
        $server = $order->server_id ? Server::query()->find($order->server_id) : null;

        return response()->json([
            'status' => $order->status,
            'note' => $order->note,
            'seconds_remaining' => $order->qris_expires_at ? (int) max(0, now()->diffInSeconds($order->qris_expires_at, false)) : 0,
            'redirect' => $order->status === 'active' && $server ? '/server/' . $server->uuidShort : null,
        ]);
    }

    public function newQris(string $id)
    {
        $order = $this->mine($id);

        try {
            $this->billing->renewQris($this->billing->refresh($order));
        } catch (PortalException $e) {
            return back()->withErrors(['order' => $e->getMessage()]);
        }

        return redirect()->route('localcloud.portal.order', $order->public_id);
    }

    public function subscriptions()
    {
        $subs = Subscription::query()->with('plan')->where('user_id', Auth::id())->where('status', '!=', 'deleted')->latest()->get();
        $servers = Server::query()->whereIn('id', $subs->pluck('server_id'))->get()->keyBy('id');

        return view('localcloud.subscriptions', ['subs' => $subs, 'servers' => $servers]);
    }

    public function renew(Request $request, int $id)
    {
        $data = $request->validate(['cycle' => ['required', 'in:month,year']]);
        $sub = Subscription::query()->with('plan')->where('user_id', Auth::id())->findOrFail($id);

        try {
            $order = $this->billing->createRenewal(Auth::user(), $sub, $data['cycle'], (string) $request->ip());
        } catch (PortalException $e) {
            return back()->withErrors(['renew' => $e->getMessage()]);
        }

        return redirect()->route('localcloud.portal.order', $order->public_id);
    }

    private function mine(string $id): Order
    {
        return Order::query()->where('public_id', $id)->where('user_id', Auth::id())->firstOrFail();
    }
}
