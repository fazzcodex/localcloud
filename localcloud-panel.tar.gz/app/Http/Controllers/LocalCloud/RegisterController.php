<?php

namespace Pterodactyl\Http\Controllers\LocalCloud;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\LocalCloud\Portal\PortalException;
use Pterodactyl\Services\LocalCloud\Portal\RegistrationService;

class RegisterController extends Controller
{
    public function __construct(private RegistrationService $registration)
    {
    }

    public function show(Request $request)
    {
        abort_unless(config('localcloud.registration_enabled'), 404);

        $ref = (string) $request->query('ref', '');
        if (preg_match('/^[A-Za-z0-9]{4,16}$/', $ref)) {
            session(['lc_ref' => strtoupper($ref)]);
        }

        return view('localcloud.register', [
            'ref' => session('lc_ref'),
            'siteKey' => $this->registration->turnstileEnabled() ? config('localcloud.turnstile_site_key') : null,
        ]);
    }

    public function store(Request $request)
    {
        abort_unless(config('localcloud.registration_enabled'), 404);

        $data = $request->validate([
            'email' => ['required', 'email:rfc', 'max:191'],
            'username' => ['required', 'string', 'min:3', 'max:30', 'regex:/^[a-z0-9]([\w\.-]*[a-z0-9])?$/i'],
            'password' => ['required', 'string', 'min:8', 'max:100', 'confirmed'],
            'terms' => ['accepted'],
        ], [
            'username.regex' => 'Username hanya boleh huruf, angka, titik, strip, atau underscore.',
            'password.confirmed' => 'Konfirmasi password tidak sama.',
            'password.min' => 'Password minimal 8 karakter.',
            'terms.accepted' => 'Anda harus menyetujui Syarat Layanan.',
        ]);

        if (!$this->registration->turnstileOk($request->input('cf-turnstile-response'), (string) $request->ip())) {
            return back()->withInput($request->except('password', 'password_confirmation'))
                ->withErrors(['captcha' => 'Verifikasi captcha gagal. Coba lagi.']);
        }

        try {
            $this->registration->start($data['email'], $data['username'], $data['password'], (string) $request->ip(), session('lc_ref'));
        } catch (PortalException $e) {
            return back()->withInput($request->except('password', 'password_confirmation'))->withErrors(['email' => $e->getMessage()]);
        }

        return redirect()->route('localcloud.register.sent')->with('email', strtolower($data['email']));
    }

    public function sent()
    {
        return view('localcloud.notice', [
            'title' => 'Cek email Anda',
            'message' => 'Kami mengirim tautan verifikasi ke ' . e(session('email', 'email Anda')) . '. Akun aktif setelah tautan dibuka (berlaku 24 jam). Periksa juga folder spam.',
        ]);
    }

    public function verify(string $token)
    {
        try {
            $this->registration->verify($token);
        } catch (PortalException $e) {
            return view('localcloud.notice', ['title' => 'Verifikasi gagal', 'message' => $e->getMessage(), 'link' => ['/register', 'Daftar ulang']]);
        }

        return view('localcloud.notice', [
            'title' => 'Email terverifikasi',
            'message' => 'Akun Anda sudah aktif. Silakan masuk dan deploy server pertama Anda.',
            'link' => ['/auth/login', 'Masuk sekarang'],
        ]);
    }
}
