<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\LocalCloud\HealthService;

class HealthController extends Controller
{
    public function __construct(private HealthService $health)
    {
    }

    public function index(): View
    {
        return view('admin.health.index', ['snapshot' => $this->health->snapshot()]);
    }

    public function json(): JsonResponse
    {
        return response()->json($this->health->snapshot());
    }
}
