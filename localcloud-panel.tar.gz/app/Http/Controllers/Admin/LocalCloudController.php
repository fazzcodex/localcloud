<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Models\LocalCloud\Plan;
use Pterodactyl\Models\LocalCloud\Order;
use Pterodactyl\Models\LocalCloud\Template;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\LocalCloud\Subscription;
use Pterodactyl\Services\Servers\SuspensionService;
use Pterodactyl\Services\LocalCloud\Portal\BillingService;

class LocalCloudController extends Controller
{
    public function __construct(private BillingService $billing, private SuspensionService $suspension)
    {
    }

    public function index()
    {
        $flagged = Subscription::query()->with('plan')->where('status', 'suspended')->where('suspend_reason', 'abuse')->get();

        return view('admin.localcloud.index', [
            'plans' => Plan::query()->orderBy('sort')->get(),
            'templates' => Template::query()->orderBy('sort')->get(),
            'orders' => Order::query()->with(['plan', 'template'])->latest()->limit(50)->get(),
            'flagged' => $flagged,
            'servers' => Server::query()->whereIn('id', $flagged->pluck('server_id'))->get()->keyBy('id'),
            'users' => User::query()->whereIn('id', Order::query()->latest()->limit(50)->pluck('user_id'))->get(['id', 'username', 'email'])->keyBy('id'),
        ]);
    }

    private function rules(): array
    {
        return [
            'name' => 'required|string|max:80',
            'ram_mb' => 'required|integer|min:128|max:1048576',
            'cpu_percent' => 'required|integer|min:1|max:10000',
            'disk_mb' => 'required|integer|min:128|max:10485760',
            'backups' => 'required|integer|min:0|max:100',
            'databases' => 'required|integer|min:0|max:100',
            'extra_ports' => 'required|integer|min:0|max:100',
            'price_month' => 'required|integer|min:0|max:100000000',
            'price_year' => 'required|integer|min:0|max:1000000000',
            'trial_days' => 'nullable|integer|min:0|max:365',
            'stock' => 'nullable|integer|min:0|max:100000',
            'sort' => 'nullable|integer|min:0|max:1000',
        ];
    }

    public function savePlan(Request $request, int $id)
    {
        $plan = Plan::query()->findOrFail($id);
        $data = $request->validate($this->rules());

        $plan->update($this->normalise($request, $data));

        return redirect()->route('admin.localcloud')->with('success', "Plan {$plan->name} disimpan.");
    }

    public function createPlan(Request $request)
    {
        $data = $request->validate($this->rules() + ['slug' => 'required|alpha_dash|max:40|unique:localcloud_plans,slug']);

        Plan::query()->create($this->normalise($request, $data) + ['slug' => $data['slug']]);

        return redirect()->route('admin.localcloud')->with('success', 'Plan dibuat.');
    }

    private function normalise(Request $request, array $data): array
    {
        return [
            'name' => $data['name'],
            'ram_mb' => $data['ram_mb'],
            'cpu_percent' => $data['cpu_percent'],
            'disk_mb' => $data['disk_mb'],
            'backups' => $data['backups'],
            'databases' => $data['databases'],
            'extra_ports' => $data['extra_ports'],
            'price_month' => $data['price_month'],
            'price_year' => $data['price_year'],
            'trial_days' => (int) ($data['trial_days'] ?? 0),
            'stock' => ($data['stock'] ?? '') === '' ? null : (int) $data['stock'],
            'sort' => (int) ($data['sort'] ?? 0),
            'popular' => $request->boolean('popular'),
            'active' => $request->boolean('active'),
            'is_trial' => $request->boolean('is_trial'),
        ];
    }

    public function toggleTemplate(int $id)
    {
        $template = Template::query()->findOrFail($id);
        $template->update(['active' => !$template->active]);

        return redirect()->route('admin.localcloud')->with('success', "Template {$template->name} " . ($template->active ? 'diaktifkan' : 'dinonaktifkan') . '.');
    }

    public function retryOrder(string $id)
    {
        $order = Order::query()->where('public_id', $id)->firstOrFail();
        if (!in_array($order->status, ['failed', 'paid'], true) || !$order->paid_at) {
            return redirect()->route('admin.localcloud')->withErrors(['order' => 'Hanya pesanan yang sudah dibayar (paid/failed) yang bisa diproses ulang.']);
        }

        $order->update(['status' => 'paid', 'attempts' => 0, 'note' => null]);
        $this->billing->fulfill($order->fresh());

        return redirect()->route('admin.localcloud')->with('success', 'Pesanan diproses ulang. Status: ' . $order->fresh()->status . '.');
    }

    public function restore(int $id)
    {
        $sub = Subscription::query()->findOrFail($id);
        $server = Server::query()->find($sub->server_id);
        if ($server) {
            $this->suspension->toggle($server, SuspensionService::ACTION_UNSUSPEND);
            Cache::forget('localcloud:abuse:' . $server->id);
        }
        $sub->update(['status' => 'active', 'suspend_reason' => null, 'suspended_at' => null, 'grace_ends_at' => null]);

        return redirect()->route('admin.localcloud')->with('success', 'Server dipulihkan.');
    }
}
