<?php

namespace Pterodactyl\Models\LocalCloud;

use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    protected $table = 'localcloud_subscriptions';

    protected $guarded = [];

    protected $casts = [
        'is_trial' => 'boolean',
        'reminded_3d' => 'boolean',
        'reminded_1d' => 'boolean',
        'expires_at' => 'datetime',
        'suspended_at' => 'datetime',
        'grace_ends_at' => 'datetime',
    ];

    public function plan()
    {
        return $this->belongsTo(Plan::class, 'plan_id');
    }
}
