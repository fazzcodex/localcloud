<?php

namespace Pterodactyl\Models\LocalCloud;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $table = 'localcloud_coupons';

    protected $guarded = [];

    protected $casts = [
        'new_users_only' => 'boolean',
        'active' => 'boolean',
        'starts_at' => 'datetime',
        'expires_at' => 'datetime',
    ];
}
