<?php

namespace Pterodactyl\Models\LocalCloud;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    protected $table = 'localcloud_plans';

    protected $guarded = [];

    protected $casts = [
        'is_trial' => 'boolean',
        'popular' => 'boolean',
        'active' => 'boolean',
    ];

    public function priceFor(string $cycle): int
    {
        return match ($cycle) {
            'year' => (int) $this->price_year,
            'month' => (int) $this->price_month,
            default => 0,
        };
    }

    /** Effective monthly price when billed yearly. */
    public function yearlyPerMonth(): int
    {
        return (int) round($this->price_year / 12);
    }

    public function periodDays(string $cycle): int
    {
        return match ($cycle) {
            'year' => 365,
            'month' => 30,
            default => max(1, (int) $this->trial_days),
        };
    }
}
