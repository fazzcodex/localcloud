<?php

namespace Pterodactyl\Models\LocalCloud;

use Illuminate\Database\Eloquent\Model;

class Template extends Model
{
    protected $table = 'localcloud_templates';

    protected $guarded = [];

    protected $casts = [
        'environment' => 'array',
        'active' => 'boolean',
    ];
}
