<?php

namespace Pterodactyl\Models\LocalCloud;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'localcloud_orders';

    protected $guarded = [];

    protected $casts = [
        'qris_expires_at' => 'datetime',
        'paid_at' => 'datetime',
    ];

    public function plan()
    {
        return $this->belongsTo(Plan::class, 'plan_id');
    }

    public function template()
    {
        return $this->belongsTo(Template::class, 'template_id');
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }
}
