<?php

// Knowledge-base articles shown at /docs. Bodies are trusted static HTML.
return [
    'mulai-cepat' => [
        'title' => 'Membuat server pertama Anda',
        'summary' => 'Dari daftar sampai aplikasi berjalan dalam beberapa menit.',
        'body' => '<ol><li>Daftar di halaman <a href="/register">Daftar</a>, lalu buka tautan verifikasi yang dikirim ke email Anda.</li>
<li>Masuk, klik <strong>Create Server</strong> di dashboard, dan pilih runtime (Node.js, Python, Bun, Java, atau Linux).</li>
<li>Pilih plan. Pilih <em>Free Trial</em> bila ingin mencoba tanpa biaya (satu kali per akun).</li>
<li>Beri nama server. Untuk plan berbayar, scan kode QRIS dan halaman akan berpindah sendiri setelah pembayaran terverifikasi.</li>
<li>Buka tab <strong>Console</strong> dan tunggu pesan <code>[LocalCloud] Application starting</code>. Aplikasi contoh akan berjalan di port server Anda.</li></ol>',
    ],
    'upload-file' => [
        'title' => 'Mengunggah dan mengedit file',
        'summary' => 'Pakai File Manager untuk memindahkan kode aplikasi Anda.',
        'body' => '<p>Buka tab <strong>Files</strong>. Klik <strong>Upload</strong> untuk mengunggah file atau seret file ke jendela. Klik nama file untuk mengedit langsung di browser. Hentikan server sebelum mengganti file yang sedang dipakai.</p>
<p>Folder kerja server adalah <code>/home/container</code>. Pastikan nama file utama sama dengan variabel <em>Main File</em> di tab <strong>Startup</strong> (misalnya <code>index.js</code> atau <code>main.py</code>).</p>',
    ],
    'deploy-git' => [
        'title' => 'Deploy dari repositori Git',
        'summary' => 'Clone otomatis dan pull setiap restart.',
        'body' => '<p>Di tab <strong>Startup</strong>, isi <em>Git Repository</em> dengan URL HTTPS repositori publik, dan <em>Git Branch</em> bila perlu. Repositori di-clone saat instalasi pertama; untuk server yang sudah berjalan, buka <strong>Settings → Reinstall</strong> (file lama dapat tertimpa, buat backup dulu).</p>
<p>Set <em>Auto Update</em> ke <code>1</code> agar <code>git pull</code> berjalan setiap server dinyalakan. Dependensi (<code>package.json</code> atau <code>requirements.txt</code>) dipasang otomatis.</p>',
    ],
    'variabel' => [
        'title' => 'Mengubah file utama dan paket tambahan',
        'summary' => 'Atur perintah start lewat variabel Startup.',
        'body' => '<p>Tab <strong>Startup</strong> menampilkan variabel template Anda:</p>
<ul><li><strong>Main File</strong> — file yang dijalankan (<code>index.js</code>, <code>main.py</code>, …).</li><li><strong>Extra Packages</strong> — paket npm/pip yang dipasang sebelum start.</li><li><strong>Startup Command</strong> (template Linux) — perintah bebas, mis. <code>./aplikasi --port $SERVER_PORT</code>.</li></ul>
<p>Aplikasi Anda harus mendengarkan di <code>0.0.0.0</code> pada port yang tersedia di variabel lingkungan <code>SERVER_PORT</code>.</p>',
    ],
    'port-jaringan' => [
        'title' => 'Port dan jaringan',
        'summary' => 'Alamat server dan port tambahan.',
        'body' => '<p>Alamat dan port utama server tampil di kartu server dan tab <strong>Network</strong>. Port tambahan tersedia sesuai plan Anda; tambahkan lewat tombol <strong>Create Allocation</strong> di tab Network bila kuota masih ada.</p>',
    ],
    'backup' => [
        'title' => 'Backup dan restore',
        'summary' => 'Amankan data sebelum perubahan besar.',
        'body' => '<p>Buka tab <strong>Backups</strong> lalu <strong>Create Backup</strong>. Jumlah backup mengikuti plan Anda. Untuk memulihkan, pilih backup lalu <strong>Restore</strong>; server akan dihentikan selama proses. Unduh backup penting ke perangkat Anda secara berkala.</p>',
    ],
    'perpanjang' => [
        'title' => 'Perpanjangan dan masa tenggang',
        'summary' => 'Apa yang terjadi saat masa aktif habis.',
        'body' => '<p>Anda mendapat email pengingat 3 hari dan 1 hari sebelum berakhir. Perpanjang di <a href="/portal/subscriptions">Langganan</a> dengan QRIS. Bila lewat, server ditangguhkan dan datanya disimpan selama masa tenggang (default 7 hari) sebelum dihapus permanen. Free trial tidak dapat diperpanjang.</p>',
    ],
];
