<?php

return [
    // User IDs allowed to manage nodes, locations, database hosts, panel settings and API keys.
    'super_admin_ids' => array_values(array_filter(array_map(
        'intval',
        explode(',', (string) env('LOCALCLOUD_SUPER_ADMIN_IDS', '1'))
    ))),

    // Optional default backdrop for the login page (https URL or a path under /public, e.g. /localcloud/login.jpg).
    // Users can still pick their own per browser from the palette button on the login page.
    'login_background' => env('LOCALCLOUD_LOGIN_BG'),

    // Show per-node status (names are public) on /status. Set LOCALCLOUD_STATUS_NODES=false to hide.
    'status_show_nodes' => (bool) env('LOCALCLOUD_STATUS_NODES', true),

    // ---- Portal (register, plans, payments) ----------------------------------------------------------
    'site_name' => env('LOCALCLOUD_SITE_NAME', 'LocalCloud'),
    'support_url' => env('LOCALCLOUD_SUPPORT_URL', ''),          // Discord / WhatsApp link shown in the footer
    'support_email' => env('LOCALCLOUD_SUPPORT_EMAIL', ''),

    // Payment gateway (QRIS). Keep the key server-side only; never expose it to the browser.
    'pg_url' => rtrim((string) env('LOCALCLOUD_PG_URL', 'https://pg.fazzcode.eu.cc'), '/'),
    'pg_key' => env('LOCALCLOUD_PG_KEY'),

    // Cloudflare Turnstile. Leave empty to disable the captcha (not recommended on a public site).
    'turnstile_site_key' => env('LOCALCLOUD_TURNSTILE_SITE_KEY'),
    'turnstile_secret' => env('LOCALCLOUD_TURNSTILE_SECRET'),

    'max_servers_per_account' => (int) env('LOCALCLOUD_MAX_SERVERS', 3),
    'grace_days' => (int) env('LOCALCLOUD_GRACE_DAYS', 7),
    'registration_enabled' => (bool) env('LOCALCLOUD_REGISTRATION', true),
    'verify_token_hours' => 24,

    // Auto-suspend servers that keep their CPU pinned near the plan limit (typical of crypto-miners).
    'abuse_enabled' => (bool) env('LOCALCLOUD_ABUSE_WATCH', true),
    'abuse_cpu_percent' => (float) env('LOCALCLOUD_ABUSE_CPU_PERCENT', 95),   // % of the plan's CPU limit
    'abuse_samples' => (int) env('LOCALCLOUD_ABUSE_SAMPLES', 30),              // consecutive checks (2 min each)
    // Set LOCALCLOUD_LEGAL_REVIEWED=true once the Terms/Privacy/Refund drafts were reviewed; hides the "draft" banner.
    'legal_reviewed' => (bool) env('LOCALCLOUD_LEGAL_REVIEWED', false),

    // Extra disposable-mail domains (comma separated) on top of the built-in list.
    'blocked_email_domains' => array_values(array_filter(array_map('trim', explode(',', strtolower((string) env('LOCALCLOUD_BLOCKED_EMAIL_DOMAINS', '')))))),
];
