<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class () extends Migration {
    public function up(): void
    {
        Schema::create('localcloud_status_checks', function (Blueprint $table) {
            $table->id();
            $table->string('service', 64);
            $table->boolean('ok');
            $table->unsignedInteger('latency_ms')->nullable();
            $table->timestamp('checked_at')->useCurrent();

            $table->index(['service', 'checked_at']);
            $table->index('checked_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('localcloud_status_checks');
    }
};
