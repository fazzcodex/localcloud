<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class () extends Migration {
    public function up(): void
    {
        Schema::table('localcloud_subscriptions', function (Blueprint $table) {
            $table->string('suspend_reason', 20)->nullable()->after('status'); // null | abuse
        });
    }

    public function down(): void
    {
        Schema::table('localcloud_subscriptions', function (Blueprint $table) {
            $table->dropColumn('suspend_reason');
        });
    }
};
