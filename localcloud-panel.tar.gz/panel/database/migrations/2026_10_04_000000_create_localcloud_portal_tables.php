<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class () extends Migration {
    public function up(): void
    {
        Schema::create('localcloud_plans', function (Blueprint $table) {
            $table->id();
            $table->string('slug', 40)->unique();
            $table->string('name', 80);
            $table->unsignedInteger('ram_mb');
            $table->unsignedInteger('cpu_percent');
            $table->unsignedInteger('disk_mb');
            $table->unsignedSmallInteger('backups')->default(1);
            $table->unsignedSmallInteger('databases')->default(0);
            $table->unsignedSmallInteger('extra_ports')->default(0);
            $table->unsignedInteger('price_month')->default(0);  // IDR
            $table->unsignedInteger('price_year')->default(0);   // IDR, total for 12 months
            $table->boolean('is_trial')->default(false);
            $table->unsignedSmallInteger('trial_days')->default(0);
            $table->unsignedInteger('stock')->nullable();         // null = unlimited
            $table->boolean('popular')->default(false);
            $table->boolean('active')->default(true);
            $table->unsignedSmallInteger('sort')->default(0);
            $table->timestamps();
        });

        Schema::create('localcloud_templates', function (Blueprint $table) {
            $table->id();
            $table->string('slug', 40)->unique();
            $table->string('name', 80);
            $table->string('description', 255)->default('');
            $table->string('icon', 40)->default('box');
            $table->unsignedInteger('egg_id')->nullable();
            $table->string('docker_image', 191)->nullable();
            $table->json('environment')->nullable();
            $table->boolean('active')->default(true);
            $table->unsignedSmallInteger('sort')->default(0);
            $table->timestamps();
        });

        Schema::create('localcloud_registrations', function (Blueprint $table) {
            $table->id();
            $table->string('email', 191)->unique();
            $table->string('username', 191);
            $table->string('password_hash');
            $table->string('token_hash', 64)->index();
            $table->string('ip', 45)->nullable();
            $table->timestamp('expires_at');
            $table->timestamp('created_at')->useCurrent();
        });

        Schema::create('localcloud_trial_claims', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id')->unique();
            $table->string('email_norm', 191)->unique();
            $table->string('ip', 45)->index();
            $table->timestamp('created_at')->useCurrent();
        });

        Schema::create('localcloud_orders', function (Blueprint $table) {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->unsignedInteger('user_id')->index();
            $table->unsignedBigInteger('plan_id');
            $table->unsignedBigInteger('template_id')->nullable();
            $table->unsignedBigInteger('subscription_id')->nullable();   // set for renewals
            $table->string('server_name', 80)->nullable();
            $table->string('cycle', 10);                                  // trial | month | year
            $table->unsignedInteger('amount')->default(0);
            $table->string('status', 20)->default('pending')->index();   // pending|paid|active|expired|failed
            $table->string('qris_id', 64)->nullable()->index();
            $table->string('trx_id', 64)->nullable();
            $table->string('pg_tx_id', 80)->nullable()->unique();         // blocks one payment paying two orders
            $table->timestamp('qris_expires_at')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->unsignedInteger('server_id')->nullable();
            $table->unsignedSmallInteger('attempts')->default(0);
            $table->string('note', 255)->nullable();
            $table->string('ip', 45)->nullable();
            $table->timestamps();
        });

        Schema::create('localcloud_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id')->index();
            $table->unsignedInteger('server_id')->unique();
            $table->unsignedBigInteger('plan_id');
            $table->string('cycle', 10);
            $table->boolean('is_trial')->default(false);
            $table->string('status', 20)->default('active')->index();    // active|suspended|deleted
            $table->timestamp('expires_at')->index();
            $table->timestamp('suspended_at')->nullable();
            $table->timestamp('grace_ends_at')->nullable();
            $table->boolean('reminded_3d')->default(false);
            $table->boolean('reminded_1d')->default(false);
            $table->timestamps();
        });

        // Sample plans (editable in the database / future admin page). Prices are in IDR.
        $now = now();
        $plans = [
            ['trial', 'Free Trial', 512, 50, 2048, 0, 0, 0, 0, 0, true, 5, 1, 0],
            ['starter', 'Starter', 1024, 100, 5120, 1, 0, 0, 15000, 153000, false, 0, 0, 1],
            ['basic', 'Basic', 2048, 150, 10240, 2, 1, 1, 30000, 306000, false, 0, 1, 2],
            ['plus', 'Plus', 4096, 200, 25600, 3, 2, 2, 55000, 561000, false, 0, 0, 3],
            ['pro', 'Pro', 8192, 300, 51200, 5, 3, 3, 100000, 1020000, false, 0, 0, 4],
        ];
        foreach ($plans as [$slug, $name, $ram, $cpu, $disk, $bk, $db, $ports, $pm, $py, $trial, $days, $popular, $sort]) {
            DB::table('localcloud_plans')->insert([
                'slug' => $slug, 'name' => $name, 'ram_mb' => $ram, 'cpu_percent' => $cpu, 'disk_mb' => $disk,
                'backups' => $bk, 'databases' => $db, 'extra_ports' => $ports,
                'price_month' => $pm, 'price_year' => $py, 'is_trial' => $trial, 'trial_days' => $days,
                'popular' => $popular, 'active' => true, 'sort' => $sort, 'created_at' => $now, 'updated_at' => $now,
            ]);
        }
    }

    public function down(): void
    {
        foreach (['subscriptions', 'orders', 'trial_claims', 'registrations', 'templates', 'plans'] as $name) {
            Schema::dropIfExists('localcloud_' . $name);
        }
    }
};
