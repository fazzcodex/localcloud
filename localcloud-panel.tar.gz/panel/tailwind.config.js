const colors = require('tailwindcss/colors');

// LocalCloud palette. The scale is intentionally inverted from upstream: 50 is the strongest ink and
// 900 is the softest blue surface, so existing `text-neutral-*` / `bg-neutral-*` utilities render on a
// light surface without touching each component.
const gray = {
    50: '#0A1F33',
    100: '#102A43',
    200: '#1E3A56',
    300: '#3E5C7A',
    400: '#5B7790',
    500: '#8CA3BA',
    600: '#E6EEF9',
    700: '#FFFFFF',
    800: '#F4F8FF',
    900: '#DCEBFF',
};

const brand = {
    50: '#F0F6FF',
    100: '#DCEBFF',
    200: '#BCD7FF',
    300: '#93BCFF',
    400: '#6EA8FF',
    500: '#4C93F5',
    600: '#2F80ED',
    700: '#1F63C2',
    800: '#184C94',
    900: '#123868',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#0B1D31',
                ink: '#102A43',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: brand,
                blue: brand,
                gray: gray,
                neutral: gray,
                cyan: brand,
                green: { ...colors.green, 500: '#20B486', 600: '#178F6A' },
                yellow: { ...colors.yellow, 500: '#F2B84B' },
                red: { ...colors.red, 500: '#E05252', 600: '#C73E3E' },
            },
            borderRadius: {
                DEFAULT: '14px',
                md: '14px',
                lg: '18px',
                xl: '20px',
            },
            boxShadow: {
                // Soft neo-brutalism: hard offset shadows in ink.
                DEFAULT: '3px 3px 0 #102A43',
                md: '4px 4px 0 #102A43',
                lg: '5px 5px 0 #102A43',
                xl: '6px 6px 0 #102A43',
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
