const colors = require('tailwindcss/colors');

// LocalCloud dark palette: calm slate-navy surfaces, soft blue accent. Standard (non-inverted) scale:
// 50 is the lightest text, 900 the deepest surface.
const gray = {
    50: '#F3F6FB',
    100: '#E6EDF7',
    200: '#CBD6E6',
    300: '#A5B4C9',
    400: '#8394AB',
    500: '#5E6F86',
    600: '#263447',
    700: '#1A2535',
    800: '#121B28',
    900: '#0C131D',
};

const brand = {
    50: '#F0F6FF',
    100: '#DCEBFF',
    200: '#BCD7FF',
    300: '#93BCFF',
    400: '#6EA8FF',
    500: '#4C93F5',
    600: '#2F80ED',
    700: '#1F63C2',
    800: '#184C94',
    900: '#123868',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#0A111A',
                ink: '#0C131D',
                line: '#2B3A50',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: brand,
                blue: brand,
                gray: gray,
                neutral: gray,
                cyan: brand,
                green: { ...colors.green, 500: '#20B486', 600: '#178F6A' },
                yellow: { ...colors.yellow, 500: '#F2B84B' },
                red: { ...colors.red, 500: '#E05252', 600: '#C73E3E' },
            },
            borderRadius: {
                DEFAULT: '14px',
                md: '14px',
                lg: '18px',
                xl: '20px',
            },
            boxShadow: {
                DEFAULT: '0 1px 2px rgba(0,0,0,.35), 0 4px 12px rgba(0,0,0,.2)',
                md: '0 2px 4px rgba(0,0,0,.35), 0 8px 20px rgba(0,0,0,.25)',
                lg: '0 4px 8px rgba(0,0,0,.35), 0 12px 32px rgba(0,0,0,.3)',
                xl: '0 8px 16px rgba(0,0,0,.4), 0 20px 48px rgba(0,0,0,.35)',
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
